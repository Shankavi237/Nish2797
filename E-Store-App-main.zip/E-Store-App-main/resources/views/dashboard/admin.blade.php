@extends('dashboard.header')

@section('content')
<h1>Welcome to Admin Dashboard</h1>
@endsection

