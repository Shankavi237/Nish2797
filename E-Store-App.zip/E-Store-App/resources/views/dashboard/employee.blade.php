@extends('dashboard.header')

@section('content')
<h1>Welcome to Employee Dashboard</h1>
@endsection
