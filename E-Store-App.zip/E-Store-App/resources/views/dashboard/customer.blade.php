@extends('dashboard.header')

@section('content')
<h1>Welcome to Customer Dashboard</h1>
@endsection
