

<?php $__env->startSection('content'); ?>

<h4>Details of Employee</h4>

<div>
    <strong>Name:</strong>
    <?php echo e($employee->name); ?>

</div>
<div>
    <strong>Email:</strong>
    <?php echo e($employee->email); ?>

</div>
<div>
    <strong>Gender:</strong>
    <?php echo e($employee->gender); ?>

</div>
<div>
    <strong>Address:</strong>
    <?php echo e($employee->address); ?>

</div>
<div>
    <strong>Mobile No:</strong>
    <?php echo e($employee->mobile); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/employee/show.blade.php ENDPATH**/ ?>