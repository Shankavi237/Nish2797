

<?php $__env->startSection('content'); ?>

<h4>Product Details</h4>

<div>
    <strong>Name:</strong>
    <?php echo e($product->name); ?>

</div>
<div>
    <strong>Detail:</strong>
    <?php echo e($product->detail); ?>

</div>
<div>
    <strong>Price:</strong>
    <?php echo e($product->price); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/product/show.blade.php ENDPATH**/ ?>