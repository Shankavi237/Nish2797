

<?php $__env->startSection('content'); ?>
<h4>Edit a Product</h4>

<!-- Authentication Error -->
<?php if($errors->any()): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div>
        <strong>Name:</strong>
        <input type="text" name="name" value="<?php echo e($product->name); ?>">
    </div>
    <div>
        <strong>Detail:</strong>
        <textarea style="height:150px" name="detail"><?php echo e($product->detail); ?></textarea>
    </div>
    <div>
        <strong>price:</strong>
        <input type="text" name="price" value="<?php echo e($product->price); ?>">
    </div>
    <div>
    <button type="sumbit" name="update">Update</button>
    </div>
    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/product/edit.blade.php ENDPATH**/ ?>