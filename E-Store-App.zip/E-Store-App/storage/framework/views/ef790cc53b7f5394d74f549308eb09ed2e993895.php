

<?php $__env->startSection('content'); ?>

<table border="1px">
    <tr>
        <td>No</td>
        <td>Name</td>
        <td>Detail</td>
        <td>Price</td>
        <td>Actions</td>
    </tr>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($product->id); ?></td>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->detail); ?></td>
        <td><?php echo e($product->price); ?></td>
        <td>
            <a href="<?php echo e(route('products.order', $product->id)); ?>">Place order</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/order/placeorder.blade.php ENDPATH**/ ?>