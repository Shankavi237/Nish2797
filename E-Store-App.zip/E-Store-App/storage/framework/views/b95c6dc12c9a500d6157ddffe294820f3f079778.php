

<?php $__env->startSection('content'); ?>
<h4>Edit an Employee</h4>

<!-- Authentication Error -->
<?php if($errors->any()): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('users.update', $employee->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div>
        <strong>Name:</strong>
        <input type="text" name="name" value="<?php echo e($employee->name); ?>">
    </div>
    <div>
        <strong>Email:</strong>
        <input type="text" name="email" value="<?php echo e($employee->email); ?>">
    </div>
    <div>
        <label for ="gender">Gender: </label>
        <select name="gender">
            <option value="m">Male</option>
            <option value="f">Female</option>
        </select>
    </div>
    <div>
        <strong>Address:</strong>
        <input type="text" name="address" value="<?php echo e($employee->address); ?>">
    </div>
    <div>
        <strong>Mobile No:</strong>
        <input type="text" name="mobile" value="<?php echo e($employee->mobile); ?>">
    </div>
    <div>
        <button type="sumbit" name="update">Update</button>
    </div>
    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/employee/edit.blade.php ENDPATH**/ ?>