<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Store</title>
</head>
<body>

    <div class="container">
        <h3>E-Store</h3>

        <?php if(Auth::user()->role == "admin"): ?>
            <div>
                <?php echo e(Auth::user()->name); ?>

                <a href="<?php echo e(route('products.index')); ?>">Products</a>
                <a href="<?php echo e(route('users.index')); ?>">Employees</a>
                <a href="<?php echo e(url('logout')); ?>">Logout</a>
            </div>
        <?php elseif(Auth::user()->role == "customer"): ?>
            <div>
                <?php echo e(Auth::user()->name); ?>

                <a href="<?php echo e(route('orders.index')); ?>">Place Orders</a>
                <a href="<?php echo e(url('logout')); ?>">Logout</a>
            </div>
        <?php elseif(Auth::user()->role == "employee"): ?>
            <div>
                <?php echo e(Auth::user()->name); ?>

                <a href="<?php echo e(route('myorder')); ?>">My Orders</a>
                <a href="<?php echo e(url('logout')); ?>">Logout</a>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\E-Lab User\Desktop\New folder\E-Store-App\resources\views/dashboard/header.blade.php ENDPATH**/ ?>