<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <form action="<?php echo e(route('users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Authention Error -->
        <?php if($message = Session::get('error')): ?>
            <div>
                <button>><</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
            <div>
                <button>><</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>

        <!-- Validation Error -->
        <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br/>
        <?php endif; ?>
        <div>
            <label for ="name">Name: </label>
            <input type="text" name="name"><br/><br/>
        </div>
        <div>
            <label for ="email">Email: </label>
            <input type="email" name="email"><br/><br/>
        </div>
        <div>
            <label for ="gender">Gender: </label>
            <select name="gender">
                <option value="m">Male</option>
                <option value="f">Female</option>
            </select>
        </div>
        <div>
            <label for ="address">Address: </label>
            <input type="text" name="address"><br/><br/>
        </div>
        <div>
            <label for ="mobile">Mobile No: </label>
            <input type="text" name="mobile"><br/><br/>
        </div>
        <div>
            <label for ="password">Password: </label>
            <input type="password" name="password"><br/><br/>
        </div>
        <input type="hidden" name="role" value="customer">
        <button type="submit" name="submit">Sign Up</button><br/>
        <a href="<?php echo e(url('/')); ?>">I alredy have an account</a>
    </form> 
</body>
</html><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/auth/register.blade.php ENDPATH**/ ?>