

<?php $__env->startSection('content'); ?>
<h4>Add a new Product</h4>

<!-- Authentication Error -->
<?php if($errors->any()): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('products.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div>
        <strong>Name:</strong>
        <input type="text" name="name">
    </div>
    <div>
        <strong>Detail:</strong>
        <textarea style="height:150px" name="detail"></textarea>
    </div>
    <div>
        <strong>price:</strong>
        <input type="text" name="price">
    </div>
    <div>
        <button type="sumbit" name="add">Add</button>
    </div>
    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/product/create.blade.php ENDPATH**/ ?>