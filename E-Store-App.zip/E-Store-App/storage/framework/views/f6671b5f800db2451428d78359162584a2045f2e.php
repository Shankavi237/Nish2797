

<?php $__env->startSection('content'); ?>
<h4>Enroll a new Employee</h4>

<!-- Authentication Error -->
<?php if($errors->any()): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('users.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div>
        <label for ="name">Name: </label>
        <input type="text" name="name"><br/><br/>
    </div>
    <div>
        <label for ="email">Email: </label>
        <input type="email" name="email"><br/><br/>
    </div>
    <div>
        <label for ="gender">Gender: </label>
        <select name="gender">
            <option value="m">Male</option>
            <option value="f">Female</option>
        </select>
    </div>
    <div>
        <label for ="address">Address: </label>
        <input type="text" name="address"><br/><br/>
    </div>
    <div>
        <label for ="mobile">Mobile No: </label>
        <input type="text" name="mobile"><br/><br/>
    </div>
    <div>
        <label for ="password">Password: </label>
        <input type="password" name="password"><br/><br/>
    </div>
    <input type="hidden" name="role" value="employee">
    <button type="submit" name="enroll">Enroll</button><br/>
    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/employee/create.blade.php ENDPATH**/ ?>