

<?php $__env->startSection('content'); ?>
<h1>Welcome to Customer Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\E-Lab User\Desktop\New folder\E-Store-App\resources\views/dashboard/customer.blade.php ENDPATH**/ ?>