

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('users.create')); ?>">Enroll new Employee</a>

<!-- success alert message -->
<?php if($message = Session::get('success')): ?>
    <div>
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<table border="1px">
    <tr>
        <td>No</td>
        <td>Name</td>
        <td>Email</td>
        <td>Mobile</td>
        <td>Actions</td>
    </tr>
    
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($employee->id); ?></td>
        <td><?php echo e($employee->name); ?></td>
        <td><?php echo e($employee->email); ?></td>
        <td><?php echo e($employee->mobile); ?></td>
        <td>
            <form action="<?php echo e(route('users.destroy', $employee->id)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('users.show', $employee->id)); ?>">Show</a>
                <a href="<?php echo e(route('users.edit', $employee->id)); ?>">Edit</a>
                <button type="submit" name="delete">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/employee/index.blade.php ENDPATH**/ ?>