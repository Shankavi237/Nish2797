<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="POST" action="<?php echo e(url('login')); ?>">
        
        <!-- Authention Error -->
        <?php if($message = Session::get('error')): ?>
            <div>
                <button>><</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>

        <!-- Validation Error -->
        <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br/>
        <?php endif; ?>

        <?php echo csrf_field(); ?>
        <div>
            <label>Email</label>
            <input type='text' name='email'>
        </div>
        <br>
        <div>
            <label>Password</label>
            <input type='Password' name='password'>
        </div>
        <br>
        <button type="sumbit" name='login'>Login</button><br/>
        <br>
        <a href="<?php echo e(url('/register')); ?>">Register Now!</a>
        
    </form>
</body>
</html><?php /**PATH C:\Users\E-Lab User\Desktop\New folder\E-Store-App\resources\views/auth/login.blade.php ENDPATH**/ ?>