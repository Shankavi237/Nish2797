

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('orders.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div>
        <strong>Product Name: </strong>
        <?php echo e($product->name); ?>

    </div>
    <div>
        <strong>Employee Name: </strong>
        <select name="employee_id">
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{
                <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>
            }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <strong>Price: </strong>
        <?php echo e($product->price); ?>

    </div>
    <input type="hidden" name="customer_id" value="<?php echo e(Auth::user()->id); ?>">
    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
    <button type="submit" name="order">Order</button><br/>
    
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/order/create.blade.php ENDPATH**/ ?>