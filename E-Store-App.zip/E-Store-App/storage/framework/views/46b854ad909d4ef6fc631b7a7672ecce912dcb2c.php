

<?php $__env->startSection('content'); ?>
<h1>Welcome to Customer Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lakshitha\Desktop\Level 3S\Laravel\EStore\resources\views/dashboard/customer.blade.php ENDPATH**/ ?>